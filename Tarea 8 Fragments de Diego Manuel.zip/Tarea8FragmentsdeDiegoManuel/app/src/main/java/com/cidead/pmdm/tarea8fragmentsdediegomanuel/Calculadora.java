package com.cidead.pmdm.tarea8fragmentsdediegomanuel;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

public class Calculadora extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String mParam1;
    private String mParam2;

    public Calculadora() {
    }

    public static Calculadora newInstance(String param1, String param2) {
        Calculadora fragment = new Calculadora();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        EditText et1, et2;
        RadioButton rBSumar, rBRestar, rBMult, rBDiv;
        Button bTCalc;
        TextView tVResultado;
        View view = inflater.inflate(R.layout.fragment_calculadora, container, false);
        et1 = view.findViewById(R.id.eTOp1);
        et2 = view.findViewById(R.id.eTOp2);
        RadioGroup rg = view.findViewById(R.id.rGOperaciones);
        rBSumar = view.findViewById(R.id.rGSumar);
        rBRestar = view.findViewById(R.id.rGRestar);
        rBMult = view.findViewById(R.id.rGMult);
        rBDiv = view.findViewById(R.id.rGDiv);
        bTCalc = view.findViewById(R.id.bTOperar);
        tVResultado = view.findViewById(R.id.tVResultado);
        bTCalc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double op1, op2;
                double resultado;
                String sOp1 = et1.getText().toString();
                String sOp2 = et2.getText().toString();
                if (sOp1.isEmpty() || sOp2.isEmpty()) {
                    if(sOp1.isEmpty()) {
                        tVResultado.setText(R.string.err_op_1);
                    }
                    if(sOp2.isEmpty()){
                        tVResultado.setText(R.string.err_op_2);
                    }
                } else {
                    op1 = Double.parseDouble(sOp1);
                    op2 = Double.parseDouble(sOp2);

                    if (rBSumar.isChecked()) {
                        resultado = op1 + op2;
                        tVResultado.setText("El resultado de la suma es:\n\n" + String.valueOf(resultado));
                    }
                    if (rBRestar.isChecked()) {
                        resultado = op1 - op2;
                        tVResultado.setText("El resultado de la resta es:\n\n" + String.valueOf(resultado));
                    }
                    if (rBMult.isChecked()) {
                        resultado = op1 * op2;
                        tVResultado.setText("El resultado de la multipicación es:\n\n" + String.valueOf(resultado));
                    }
                    if (rBDiv.isChecked()) {
                        if (op2 == 0) {
                            tVResultado.setText(R.string.no_div_entre_0);
                        } else {
                            resultado = op1 / op2;
                            tVResultado.setText("El resultado de la division es:\n\n" + String.valueOf(resultado));
                        }
                    }
                }
            }
        });
        // Inflate the layout for this fragment
        return view;
    }
}
